#include <xxx/foo/foo.h>

#include <iostream>

void xxx::foo::Foo::trigger() {
    std::cout << "trigerring foo." << std::endl;
}