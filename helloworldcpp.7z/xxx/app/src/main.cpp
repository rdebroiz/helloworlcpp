#include <xxx/bar/bar.h>

int main() {
    xxx::bar::Bar bar;
    bar.trigger();
}