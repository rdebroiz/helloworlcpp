#include <yyy/spam/spam.h>

int main() {
    yyy::spam::Spam spam;
    spam.trigger();
}