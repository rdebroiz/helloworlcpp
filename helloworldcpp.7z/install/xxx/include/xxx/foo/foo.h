#pragma once

namespace xxx {
namespace foo {

class Foo {
    public:
        Foo() = default;
        ~Foo() = default;

        void trigger();
};

}
}